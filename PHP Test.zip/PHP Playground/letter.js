let items = [
    [1, 2],
    [3, 4],
    [5, 6]
  ];
  console.log(items[0][0]); // 1
  console.log(items[0][1]); // 2
  console.log(items[1][0]); // 3
  console.log(items[1][1]); // 4
  console.log(items);