<?php
$check = true;


echo "Displaying Letter H \n";

while($check){
    $numb = (int)readline('Enter number 1 - 100: ');
    if($numb == 0 || $numb > 100){
        echo "Invalid input. Either not a number, or 0 or number greater than 100 \n";
    }
    else{
        $check = false;
    }
}
$height = $numb * 3;
$width = $numb * 3;
$checkwidth = 0;
$checkheight = 0;
$epoch = 0;
$draw = true;
$drawAll = false;
$check = 0;

while($checkheight != $height){
    echo "\n";

    if($epoch == $numb){
        $drawAll = true;
        $draw = false;
        $checkwidth = 0;
    }

    for($i = 0; $i < $width; $i++){
        if($check == $numb){
            $drawAll = false;
        }
        if($drawAll != false && $check != $numb){
            $draw = false;
        }
        
        if($draw){
            echo "*";
            $checkwidth++;
            
            if($checkwidth == $numb){
                $draw = false;
                $checkwidth = 0;
            }
        }
        else if($drawAll){
            echo "+";
            $checkwidth++;
            if($checkwidth == $width){
                $checkwidth = 0;
                $check++;
            }
        }
        else{
            echo " ";
            $checkwidth++;
            if($checkwidth == $numb){  
                $draw = true;
                $checkwidth = 0;
            }
        }
    }
    $draw = true;
    $checkheight++;
    $epoch++;
}


        
?>